# Smart Page Replacement Simulator

A browser-based hackathon prototype that simulates and compares FIFO, LRU, and a configurable Smart page replacement policy.

## Features

- Animated RAM frame visualization, with page-hit/page-fault indicators.
- Step-through and autoplay playback.
- FIFO vs LRU vs Smart comparison using the same input sequence and frame count.
- Charts for page faults, page hits, and hit ratio.
- Configurable Smart policy weights for access frequency and recency.
- Export comparison results to CSV.
- Responsive layout for desktop and mobile browsers.

## Requirements

- A modern browser (Chrome, Edge, Firefox, or Safari).
- Internet connection to load Chart.js and Google Fonts from their CDNs. The core simulator works without Chart.js, but charts will not display offline.

No package installation or build step is required.

## Run locally

1. Extract the project ZIP.
2. Open `index.html` in a modern web browser.

If your browser restricts local file behavior, run a local static server from this directory:

### Python

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

### VS Code

Install the Live Server extension, right-click `index.html`, and choose **Open with Live Server**.

## How to use

1. Enter a comma- or space-separated page sequence, such as `1, 2, 3, 2, 4, 1, 5`.
2. Select the number of RAM frames.
3. Adjust frequency and recency weights for the Smart policy. The weights are normalized automatically; if both are zero, equal weights are used.
4. Click **Run comparison** to calculate all three policies.
5. Select FIFO, LRU, or Smart in the animation dropdown.
6. Use **Step through** or **Play animation** to inspect each request.
7. Click **Export CSV** to save the comparison table.

## Smart policy design

For every resident page `p`, the simulator calculates a score:

`score(p) = wF × normalizedFrequency(p) + wR × recencyScore(p)`

- `normalizedFrequency(p)` is the cumulative access count of that page divided by the largest cumulative access count among the current resident pages.
- `recencyScore(p) = 1 / (requestsSinceLastUse(p) + 1)`.
- `wF` and `wR` are the frequency and recency weights, normalized to sum to 1.
- When RAM is full, the resident page with the lowest score is evicted. Ties are broken by evicting the least recently used page.

This is an educational heuristic, not a claim of optimality. Its results depend on the workload and chosen weights; it may not outperform FIFO or LRU on every sequence.

## Metrics

- **Page fault:** Requested page is not currently resident in RAM.
- **Page hit:** Requested page is already resident in RAM.
- **Hit ratio:** `(page hits / total requests) × 100`.
- **Fault ratio:** `(page faults / total requests) × 100`.
- **Runtime:** Local JavaScript simulation time, which can vary with device and browser load.

All algorithms receive the same reference sequence and frame count. Runtime is a lightweight measurement and should not be treated as a benchmark of real operating-system performance.

## Project files

- `index.html` — page structure and controls.
- `style.css` — responsive layout, styling, and animation.
- `script.js` — FIFO, LRU, Smart simulation, visualization, charts, and CSV export.

## Limitations / future improvements

- This project is a simulator and does not change the host operating system's actual virtual-memory manager.
- For stronger evaluation, run multiple deterministic workloads (sequential, looping, frequency-skewed, and random) and report average page faults.
- Possible future work includes workload presets, automated weight tuning, trace-file import, and additional policies such as Optimal (used as an offline benchmark).
